﻿namespace MilitaryElite.Models.Enums
{

    public enum Corps
    {
        Airforces = 0,
        Marines = 1
    }
}
