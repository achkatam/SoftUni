﻿namespace BorderControl.Models.Interfaces
{

    public interface IIdentifiable
    {
        string Name { get; set; }

        string Id { get; set; }

        void CheckId(string idToCheck);
    }
}
