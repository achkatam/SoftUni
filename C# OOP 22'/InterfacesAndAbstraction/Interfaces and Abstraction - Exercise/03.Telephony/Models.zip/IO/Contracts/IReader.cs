﻿namespace Telephony.IO.Contracts
{
    //could be used for variable types of apps 
    public interface IReader
    {
        string ReadLine();
    }
}
