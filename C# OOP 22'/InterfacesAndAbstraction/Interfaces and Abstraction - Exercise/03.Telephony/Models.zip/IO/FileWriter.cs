﻿namespace Telephony.IO
{
    using System;

    using Telephony.IO.Contracts;

    public class FileWriter : IWriter
    {
        //TODO: Implement
        public void Write(string text)
        {
            throw new NotImplementedException();
        }

        public void Writeline(string text)
        {
            throw new NotImplementedException();
        }
    }
}
