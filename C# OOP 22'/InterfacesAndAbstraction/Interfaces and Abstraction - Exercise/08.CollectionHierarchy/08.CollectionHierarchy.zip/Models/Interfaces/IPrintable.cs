﻿namespace CollectionHierarchy.Models.Interfaces
{

    public interface IPrintable
    {
        void Print();
    }
}
