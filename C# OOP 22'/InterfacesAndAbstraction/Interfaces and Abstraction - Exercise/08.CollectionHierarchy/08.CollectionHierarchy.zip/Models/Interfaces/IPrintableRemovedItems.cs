﻿namespace CollectionHierarchy.Models.Interfaces
{

    public interface IPrintableRemovedItems
    {
        void PrintRemovedItems();
    }
}
