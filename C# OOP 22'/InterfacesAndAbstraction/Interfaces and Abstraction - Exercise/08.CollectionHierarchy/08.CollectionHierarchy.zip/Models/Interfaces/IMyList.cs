﻿namespace CollectionHierarchy.Models.Interfaces
{
    internal interface IMyList : IAddRemoveCollection
    {
        int Used { get; }
    }
}
