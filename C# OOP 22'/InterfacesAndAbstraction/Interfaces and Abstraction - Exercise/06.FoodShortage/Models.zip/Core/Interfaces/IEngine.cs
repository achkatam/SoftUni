﻿namespace BorderControl.IO.Interfaces
{


    public interface IEngine
    {
        void Run();
    }
}
