﻿namespace ChristmasPastryShop.Models.Cocktails
{
    public class Hibernation : Cocktail
    {
        private const double DEFAULT_LARGE_INITIAL_PRICE = 10.50;

        public Hibernation(string name, string size)
            : base(name, size, DEFAULT_LARGE_INITIAL_PRICE)
        {
            if (this.Size == "Large")
            {
                this.Price = DEFAULT_LARGE_INITIAL_PRICE;
            }
            else if (this.Size == "Middle")
            {

                this.Price = (2.0 / 3.0) * DEFAULT_LARGE_INITIAL_PRICE;

            }
            else if (this.Size == "Small")
            {
                this.Price = (1.0 / 3.0) * DEFAULT_LARGE_INITIAL_PRICE;
            }
        }
    }
}
