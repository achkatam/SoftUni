﻿namespace ChristmasPastryShop.Models.Cocktails
{
    using System.Runtime.CompilerServices;

    public class MulledWine : Cocktail
    {
        private const double DEFAULT_LARGE_INITIAL_PRICE = 13.50;

        public MulledWine(string name, string size) 
            : base(name, size, DEFAULT_LARGE_INITIAL_PRICE)
        {
            if (this.Size == "Large")
            {
                this.Price = DEFAULT_LARGE_INITIAL_PRICE;
            }
            else if (this.Size == "Middle")
            {

                  this.Price =  (2.0 / 3.0) * DEFAULT_LARGE_INITIAL_PRICE;
               
            }
            else if (this.Size == "Small")
            {
                this.Price = (1.0 / 3.0) * DEFAULT_LARGE_INITIAL_PRICE;
            }
        }

        
    }
}
