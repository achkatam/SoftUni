﻿namespace ChristmasPastryShop.Models.Cocktails
{
    using System;

    using ChristmasPastryShop.Models.Cocktails.Contracts;
    using ChristmasPastryShop.Utilities.Messages;

    public abstract class Cocktail : ICocktail
    {
        private string name;
      

        protected Cocktail(string name, string size, double price)
        {
            this.Name = name;
            this.Size = size;
            this.Price = price;
        }

        public string Name
        {
            get { return this.name; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException(ExceptionMessages.NameNullOrWhitespace);

                this.name = value;
            }
        }
    

        public string Size { get; private set; }

        public double Price { get; protected set; }
      

        public override string ToString()
            => $"{this.Name} ({this.Size}) - {this.Price:f2} lv";
    }
}
