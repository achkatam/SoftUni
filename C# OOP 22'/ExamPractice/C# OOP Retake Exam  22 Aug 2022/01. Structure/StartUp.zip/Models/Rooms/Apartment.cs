﻿namespace BookingApp.Models.Rooms
{ 

    public class Apartment : Room
    {
        public Apartment(int bedCapacity) : base(6)
        {
        }
    }
}
