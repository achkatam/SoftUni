﻿namespace BookingApp.Models.Rooms
{ 

    public class Studio : Room
    {
        public Studio(int bedCapacity) : base(4)
        {
        }
    }
}
