﻿namespace BookingApp.Models.Rooms
{ 

    public class DoubleBed : Room
    {
        public DoubleBed(int bedCapacity) : base(2)
        {
        }
    }
}
