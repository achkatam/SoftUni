﻿using Heroes.Models.Contracts;
using Heroes.Models.Weapons;
using Heroes.Utilities;
using System;
using System.Reflection.Metadata.Ecma335;

namespace Heroes.Models.Heroes
{

    public abstract class Hero : IHero
    {
        private string name;
        private int health;
        private int armour;
        private IWeapon weapon;

        protected Hero(string name, int health, int armour)
        {
            this.Name = name;
            this.Health = health;
            this.Armour = armour;
        }

        public string Name
        {
            get { return name; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                    throw new ArgumentException(ExceptionMessages.InvalidHeroName);

                this.name = value;
            }
        }

        public int Health
        {
            get { return health; }
            protected set
            {
                if (value < 0)
                    throw new ArgumentException(ExceptionMessages.InvalidHeroHealth);

                this.health = value;
            }
        }

        public int Armour
        {
            get { return armour; }
            protected set
            {
                if (value < 0)
                    throw new ArgumentException(ExceptionMessages.InvalidHeroArmour);

                this.armour = value;
            }
        }

        public IWeapon Weapon
        {
            get { return weapon; }
            private set
            {
                if (value == null)
                    throw new ArgumentException(ExceptionMessages.InvalidWeapon);

                weapon = value;
            }
        }

        public bool IsAlive => this.health > 0;

        public void AddWeapon(IWeapon weapon) => this.weapon = weapon;

        public void TakeDamage(int points)
        {
            this.Armour -= points;
            if (this.Armour <= 0)
                this.Health -= this.Armour;

        }
    }
}
