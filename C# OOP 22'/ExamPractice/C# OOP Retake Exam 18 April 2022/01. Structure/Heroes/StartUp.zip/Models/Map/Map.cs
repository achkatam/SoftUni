﻿using Heroes.Models.Contracts;
using Heroes.Models.Heroes;
namespace Heroes.Models.Map
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class Map : IMap
    {
        public string Fight(ICollection<IHero> players)
        {
            List<IHero> barbarians = new List<IHero>();
            List<IHero> knights = new List<IHero>();

            foreach (IHero hero in players)
            {
                if (hero.GetType() == typeof(Knight))
                {
                    knights.Add(hero);
                }
                else
                {
                    barbarians.Add(hero);
                }
            }

            int turnCounter = 1;

            while (knights.Any(x => x.IsAlive) && barbarians.Any(x => x.IsAlive))
            {
                if (turnCounter % 2 != 0)
                {
                    Fight(knights, barbarians);
                }
                else
                {
                    Fight(barbarians, knights);
                }
                turnCounter++;
            }

            if (knights.Any(x => x.IsAlive))
            {
                return $"The knights took {knights.Where(x => !x.IsAlive)} casualties but won the battle.";
            }
            else
            {
                return $"The barbarians took {barbarians.Where(x => !x.IsAlive)} casualties but won the battle.";
            }
        }

        private void Fight(List<IHero> attacking, List<IHero> attacked)
        {
            foreach (var attacker in attacking)
            {
                foreach (var defender in attacked)
                {
                    defender.TakeDamage(attacker.Weapon.DoDamage());
                }
            }
        }
    }
}
