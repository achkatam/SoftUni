﻿namespace AuthorProblem
{
    using System;

    [Author("Angel")]
    public class StartUp
    {
        [Author("Kyle")]
        static void Main(string[] args)
        {

        }
    }
}
