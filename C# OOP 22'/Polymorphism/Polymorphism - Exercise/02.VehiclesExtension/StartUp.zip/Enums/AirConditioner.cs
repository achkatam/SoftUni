﻿namespace Vehicles.Enums
{
using System;
using System.Collections.Generic;
using System.Text;

    public enum AirConditioner
    {
        IsOn,
        IsOff
    }
}
