﻿namespace Vehicles.Exceptions
{

    public static class ExceptionMessage
    {
        public const string InsufficientFuelExceptionMessage
            = "{0} needs refueling";
    }
}
