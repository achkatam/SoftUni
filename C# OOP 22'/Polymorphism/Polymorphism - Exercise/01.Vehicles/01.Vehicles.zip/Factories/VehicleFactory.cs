﻿namespace Vehicles.Factories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    using Vehicles.Exceptions;
    using Vehicles.Factories.Contracts;
    using Vehicles.Models;
    using Vehicles.Models.Contracts;

    public class VehicleFactory : IVehicleFactory
    {

        public VehicleFactory()
        {

        }

        public IVehicle CreateVehicle(string type, double fuelQnty, double fuelConsumption)
        {
            ////  Type types = Assembly.GetExecutingAssembly()
            //     .GetTypes().Where(t => typeof(ISortingStrategy).IsAssignableFrom(t) && t.Name.StartsWith(strategy)).FirstOrDefault();

            var vehicle = Assembly.GetExecutingAssembly()
                .GetTypes().Where(t => typeof(IVehicle).IsAssignableFrom(t) && t.Name.StartsWith(type)).FirstOrDefault();

            return (IVehicle)Activator.CreateInstance(vehicle, new object[] {  fuelQnty, fuelConsumption });


            //IVehicle vehicle;
            //if (type == "Car")
            //    vehicle = new Car(fuelQnty, fuelConsumption);
            //else if (type == "Truck")
            //    vehicle = new Truck(fuelQnty, fuelConsumption);
            //else
            //    throw new InvalidVehicleTypeException();


            //return vehicle;
        }
    }
}
