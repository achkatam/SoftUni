﻿namespace WildFarm.Models.Contracts
{

    public interface IFeline : IMamml
    {
        string Breed { get; }
    }
}
