﻿namespace WildFarm.Models.Contracts
{

    public interface IMamml : IAnimal
    {
        string LivingRegion { get; }
    }
}
