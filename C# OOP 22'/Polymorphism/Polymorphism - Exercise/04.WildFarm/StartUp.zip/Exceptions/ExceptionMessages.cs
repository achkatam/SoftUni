﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Exceptions
{
    public static class ExceptionMessages
    {
        public const string FoodNotEatenExpectionMessage
            = "{0} does not eat {1}!";
    }
}
