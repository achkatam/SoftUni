﻿namespace Raiding.Exceptions
{
    public static class ExceptionMessages
    {
        public const string InvalidHeroType = "Invalid hero!";
    }
}
