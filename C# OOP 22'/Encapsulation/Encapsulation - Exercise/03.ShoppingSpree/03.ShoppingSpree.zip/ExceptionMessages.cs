﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.ShoppingSpree
{
    public static class ExceptionMessages
    {
        public const string WrongName
            = "Name cannot be empty";

        public static string WrongInputForMoneyAndPrice
            = "Money cannot be negative";
    }
}
