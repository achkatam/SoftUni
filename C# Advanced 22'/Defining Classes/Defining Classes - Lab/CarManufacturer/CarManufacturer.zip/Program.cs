﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car()
            {
                Make = "Tesla",
                Model = "3",
                Year = 2018
            };

            Console.WriteLine($"{car.Make} {car.Model} {car.Year}");
        }
    }
}
